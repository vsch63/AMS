
var i = 0
function show_hide() {
  $('.mask').hide()
  //document.getElementById("image").style.display="block" 
  // document.getElementById("image1").style.display="none" 
  // document.getElementById("excelimage").style.display="none" 
  document.getElementById("process").style.display = "none"
  document.getElementById('FlowChart').innerHTML = 'Model';

}

function hide_image() {
  document.getElementById("process").style.display = "none"

}




function show_input(upload_type) {
  debugger;
  document.getElementById("error_messg_line").innerHTML = " "
  document.getElementById("show_upload").style.display = "none"
  document.getElementById("pb_select").style.display = "none"
  document.getElementById("show_excel").style.display = "none"
  //document.getElementById("excelimage").style.display="none"
  //document.getElementById("error_messg_line").style.display="none"
  document.getElementById("process").style.display = "none"
  //var hostip=document.getElementById("hostip").value
  var xls_image_folder = document.getElementById("xls_image_folder").value
  var xls_image_line = "<img  src=/" + xls_image_folder + "/excel.png  style='width:40px;height:40px;'> </img>"

  //document.getElementById("pb_select").innerHTML=xls_image_line
  var heading = '<form method="post" action="{{hostname}}/success"   enctype="multipart/form-data" >'
  switch (upload_type) {
    case 'A':
      var link = 'uploadpm'
      var xlfile = 'policymaster'
      var head_messg = 'Policy Master'
      break;
    case 'B':
      var link = 'uploadac'
      var xlfile = 'glcode'
      var head_messg = 'Account Codes'
      break;
    case 'C':
      var link = 'uploadpr'
      var xlfile = 'product'
      var head_messg = 'Product Master'
      break;
    case 'D':
      var link = 'uploadpb'
      var xlfile = 'polprod'
      var head_messg = 'Policy Benefits Master'
      break;
    case 'E':
      var link = 'uploadport'
      var xlfile = 'portfolio'
      var head_messg = 'Portfolio Master'
      break;
    case 'F':
      var link = 'uploadcohort'
      var head_messg = 'Cohort Master'
      break;
    case 'K':
      var link = 'uploadcontract'
      var head_messg = 'Contract Types'
      break;
    case 'L':
      var link = 'uploadporttype'
      var xlfile = 'porttypes'
      var head_messg = 'Portfolio Types'
      break;
    case 'M':
      var link = 'uploadcsfltype'
      var xlfile = 'cashflowtypes'
      var head_messg = 'Cashflow Types'
      break;
    case 'P':
      var link = 'uploadmasters'
      var head_messg = 'Bulk Upload Masters'
      break;

    case 'X':
      var link = 'polenq'
      var head_messg = 'Policy Enquiry'
      break;
    case 'Y':
      var link = 'glrep'
      var head_messg = 'General Ledger Summary'
      break;


  }

  var url_direct = "/" + link
  var file_link = "/exceldownload/" + xlfile
  heading += ' <legend>IFRS Data Upload -' + head_messg + '</legend>'
  document.getElementById("show_upload").style.display = "block"
  document.getElementById('sel_link').value = url_direct
  var xls_messg_line = '<label>Standard Template:To Download Sample File'
  xls_messg_line += ' <a  href=' + '/exceldownload/' + xlfile + ' target="_blank">'
  xls_messg_line += '<b>Click Here &nbsp; &nbsp;<b>'

  xls_messg_line += xls_image_line




  if (upload_type == 'F') {
    var xls_messg_line = ""
    document.getElementById("show_excel").innerHTML = " "
    document.getElementById("pb_select").style.display = "block"
    var pb_opt = " <table>"
    pb_opt += "<tr><td width='30%' >Annual Cohort &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;  "
    pb_opt += "<input width= '1%' type='radio' id='cohort' name='cohort' value='A'> </input></td>"
    pb_opt += "<tr><td width='30%' >Semi Annual Cohort    "
    pb_opt += "<input width= '1%' type='radio' id='cohort' name='cohort' value='H'> </input></td>"
    pb_opt += "<tr><td width='30%' >Quarterly Cohort &nbsp; &nbsp;  &nbsp;  "
    pb_opt += "<input width= '1%' type='radio' id='cohort' name='cohort' value='Q'> </input></td>"
    pb_opt += "<tr><td width='30%' >Monthly Cohort &nbsp; &nbsp; &nbsp;  &nbsp; "
    pb_opt += "<input width= '1%' type='radio' id='cohort' name='cohort' value='M'> </input></td>"
    pb_opt += "<table>"
    document.getElementById('pb_select').innerHTML = pb_opt
  }

  if (upload_type == 'K') {
    debugger;
    var xls_messg_line = ""
    document.getElementById("show_excel").innerHTML = " "
    document.getElementById("pb_select").style.display = "block"
    var pb_opt = " <table>"
    pb_opt += "<tr><td width='30%' >One Policy -One Contract  "
    pb_opt += "<input width= '1%' type='radio' id='cohort' name='cohort' value='S'> </input></td>"
    pb_opt += "<tr><td width='30%' >One Policy - Multiple Contracts    "
    pb_opt += "<input width= '1%' type='radio' id='cohort' name='cohort' value='M'> </input></td>"

    pb_opt += "<table>"

    document.getElementById('pb_select').innerHTML = pb_opt
  }



  if (upload_type == 'X') {
    $('.mask').show()
    document.getElementById("process").style.display = "block"
    document.getElementById("show_upload").style.display = "none"
    document.getElementById("pb_select").style.display = "none"
    //document.getElementById("excelimage").style.display="none"
    document.getElementById("error_messg_line").style.display = "none"

    var heading = "<legend> Policy Master Enquiry</legend>"
    document.getElementById('show_heading').innerHTML = heading;
    var url_direct = "/polenq"

    document.getElementById('sel_link').value = url_direct

    //form_data=''


    $.ajax({
      type: "POST",
      // data: form_data,
      contentType: false,
      cache: false,
      processData: false,
      //contentType: 'application/json;charset=UTF-8',
      url: url_direct,
      //url:hostname

      success: function (datax) {
        debugger
        document.getElementById("show_upload").style.display = "none"
        document.getElementById("pb_select").style.display = "none"
        //document.getElementById("excelimage").style.display="none"
        document.getElementById("error_messg_line").style.display = "none"
        result = datax.split("^^^")
        result[0] = result[0].replace('(', '');
        result[0] = result[0].replace('[', '');
        result[0] = result[0].replace(')', '')
        result[1] = result[1].replace('(', '');
        result[1] = result[1].replace(')', '')
        result[1] = result[1].replace('[', '');
        // result[2] = result[2].replace('(', '');
        // result[2] = result[2].replace(')', '')
        var result_final = result[0].split(',')
        var result_glcode = result[1].split(',')
        // var result_product = result[2].split(',')
        // new Date(result_final[3])
        var pb_opt = " <table>"
        pb_opt += "<tr><td width='50%' ><label>Total Records In Policy Master: "
        pb_opt += "<td>" + result_final[0] + "</label></td></tr>"
        pb_opt += "<tr><td width='50%' ><label>Start Policy Number: "
        pb_opt += "<td>" + result_final[1] + "</label></td></tr>"
        pb_opt += "<tr><td width='50%' ><label>End Policy Number: "
        pb_opt += "<td>" + result_final[2] + "</label></td></tr>"
        //pb_opt += "<tr><td width='50%' ><label>Last Updated: "
        //pb_opt += "<td>" + result_final[3] + "</label></td></tr>"
        pb_opt += "<tr><td>&nbsp;</td></tr><tr>"
        pb_opt += "</table>"
        pb_opt += "<legend> Account Codes Enquiry</legend>"
        pb_opt += " <table>"
        pb_opt += "<tr><td width='50%' ><label>Total Records In Account Codes: "
        pb_opt += "<td>" + result_glcode[0] + "</label></td></tr>"
        pb_opt += "<tr><td width='50%' ><label>Start Account Number: "
        pb_opt += "<td>" + result_glcode[1] + "</label></td></tr>"
        pb_opt += "<tr><td width='50%' ><label>End Account Number: "
        pb_opt += "<td>" + result_glcode[2] + "</label></td></tr>"
        //pb_opt += "<tr><td width='50%' ><label>Last Updated: "
        //pb_opt += "<td>" + result_glcode[3] + "</label></td></tr>"
        pb_opt += "<tr><td>&nbsp;</td></tr><tr>"
        pb_opt += "</table>"
        $('.mask').hide()
        document.getElementById("process").style.display = "none"
        document.getElementById("pb_select").style.display = "block"
        document.getElementById('pb_select').innerHTML = pb_opt
      }

    })
    return
  }

  if (upload_type == 'Y') {
    $('.mask').show()
    document.getElementById("process").style.display = "block"
    document.getElementById("show_upload").style.display = "none"
    document.getElementById("pb_select").style.display = "none"
    //document.getElementById("excelimage").style.display="none"
    document.getElementById("error_messg_line").style.display = "none"

    var heading = "<legend> General Ledger Summary</legend>"
    document.getElementById('show_heading').innerHTML = heading;
    var url_direct = "/glrep"

    document.getElementById('sel_link').value = url_direct

    //form_data=''


    $.ajax({
      type: "POST",
      // data: form_data,
      contentType: false,
      cache: false,
      processData: false,
      //contentType: 'application/json;charset=UTF-8',
      url: url_direct,
      //url:hostname

      success: function (datax) {
        
        var datay=datax.split(")),")
        
       
        document.getElementById("show_upload").style.display = "none"
        document.getElementById("pb_select").style.display = "none"
        //document.getElementById("excelimage").style.display="none"
        document.getElementById("error_messg_line").style.display = "none"
        // var result_final = datax.split("`,`")
        // alert(result_final)
        // alert(typeof(result_final))
        // alert(result_final.length)
        //result_final=result_final.replace(/\(/g, '');
        //result_final=result_final.split(/\)/g, '');
        var pb_opt = ' <div class="tabrow">'
        pb_opt += '<div class="table-responsive" style="overflow: auto;height: 370px;">'
        pb_opt += ' <table border=1 width="100%" class="table-hover" class="table table-fixed" class="table-fixed"    id="tabid">'
        pb_opt += '<tr><th>Month</th><th>Year</th><th>GL Account </th><th>Description</th><th>Amount</th></tr>'
        // var pb_opt ='<table>'
        for (var j = 0; j < datay.length; j++) {

          var result_row = datay[j].split(",")
          result_row[0] = result_row[0].replace(/\(/g, '');
          result_row[0] = result_row[0].replace(/\[/g, '');
          result_row[1] = result_row[1].replace(/\)/g, '');
          result_row[2] = result_row[2].replace(/\'/g, '');
          result_row[3] = result_row[3].replace(/\'/g, '');
          result_row[4] = result_row[4].replace(/\(/g, '');
          result_row[4] = result_row[4].replace(/\'/g, '');
          result_row[4] = result_row[4].replace(/Decimal/g, '');
          result_row[4] = result_row[4].replace(/]/g, '');
          result_row[4] = result_row[4].replace(/\)/g, '');

          pb_opt += "<tr>"
          pb_opt += "<td>" + result_row[0] + "</td>"
          pb_opt += "<td>" + result_row[1] + "</td>"
          pb_opt += "<td>" + result_row[2] + "</td>"
          pb_opt += "<td>" + result_row[3] + "</td>"
          pb_opt += "<td>" + result_row[4] + "</td>"
          pb_opt += "</tr>"


        }
        pb_opt += "</table>"

        $('.mask').hide()
        document.getElementById("process").style.display = "none"
        document.getElementById("pb_select").style.display = "block"
        document.getElementById('pb_select').innerHTML = pb_opt

      }


    })


    return
  }


  if (upload_type == 'Z') {


    document.getElementById("show_upload").style.display = "none"
    document.getElementById("pb_select").style.display = "none"
    //document.getElementById("excelimage").style.display="none"
    document.getElementById("error_messg_line").style.display = "none"

    var heading = "<legend> Error Logs</legend>"
    heading += '<select name="error_file" id="error_file" align="center" onchange="get_errors()">'
    heading += '<option value="">Select File Name</option>'
    heading += '<option value="a">Policy Master Upload Errors</option>'
    heading += '<option value="b">Account Codes Upload Errors</option>'
    heading += '<option value="c">Products Upload Errors</option>'
    heading += '<option value="d">Policy Benefits Upload Errors</option>'
    heading += '<option value="e">Portfolio Upload Errors</option>'
    heading += '<option value="f">Cohort Upload Errors</option>'
    heading += '<option value="g">Contract Types Errors</option>'
    heading += '<option value="h">Portfolio Types Errors</option>'
    heading += '<option value="i">Cash Flow Types Errors</option>'
    heading += '</select>'

    document.getElementById('show_heading').innerHTML = heading;



    return
  }

  if (upload_type != 'F' && upload_type != 'P' && upload_type != 'K') {
    var input_upload = ' <div class="tabrow">'
    input_upload += '<div class="table-responsive" style="overflow: auto;height: 370px;">'
    input_upload += ' <table  class="table-hover" class="table table-fixed" class="table-fixed"    id="tabid">'
    //var input_upload = '<br/><table  width="100%"><tr>'
    input_upload += '<td width="30%""><b> Upload File Name:</b></td>'
    input_upload += '<td><width="70%"><input class="columnp1" id="infile" name="infile" type="file" mime_type=f .content_type/></tr>'
    input_upload += '<tr><td colspan="2"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>'
    input_upload += '<tr><td></td><td>  <input class="btn btn-default" type="button" value="Submit " name="Submit"  onclick="processpm()" style="width: 90px;"></td</tr></table> '
    //document.getElementById("excelimage").style.display="block"
    document.getElementById("show_excel").style.display = "block"
    document.getElementById('show_excel').innerHTML = xls_messg_line;
  }
  if (upload_type == 'F' || upload_type == 'K') {
    var input_upload = '<tr><td></td><td>  <input class="btn btn-default" type="button" value="Submit" name="Submit" id="Submit" onclick="processpm()"></td</tr></table> '
    //document.getElementById("excelimage").style.display="none"
    document.getElementById("show_excel").style.display = "none"
  }

  if (upload_type == 'P') {
    // document.getElementById("excelimage").style.display="none"
    document.getElementById("error_messg_line").innerHTML = " "
    document.getElementById("show_excel").innerHTML = " "
    document.getElementById("show_upload").innerHTML = " "
    document.getElementById("pb_select").innerHTML = " "
    //document.getElementById("process").innerHTML=" "
    document.getElementById("show_excel").style.display = "none"
    document.getElementById("show_upload").style.display = "none"
    document.getElementById("pb_select").style.display = "none"
    document.getElementById("process").style.display = "none"
    var all_files = document.getElementById("all_files").value
    
    //var file_count = JSON.parse(document.getElementById("file_count").value)
    // var datax = all_files.split('^^^')

    //document.getElementById("process").style.display="block"
    document.getElementById("show_upload").style.display = "none"
    document.getElementById("pb_select").style.display = "none"
    //document.getElementById("excelimage").style.display="none"
    document.getElementById("error_messg_line").style.display = "none"
    var heading = "<legend> Bulk Upload Masters</legend>"
    document.getElementById('show_heading').innerHTML = heading;
    var url_direct = "/uploadmasters"

    document.getElementById('sel_link').value = url_direct
    var pb_opt = " <textarea name='Text1' cols='800' rows='5'>This option will upload all the masters directly into PAS-DM. Policy Master , Account Codes, Products , Policy Benefits, Portfolio"
    pb_opt += " will be inputs for this process. You can upload one master or multiple masters."
    pb_opt += "Files should be csv files and should be available in respective data directories.The following files are available"
    pb_opt += "for processing. Review files and click submit for uploading files.After submitting You can view the progress on Batch Upload logs.</textarea><p><p><br>"
    pb_opt += ' <div class="tabrow">'
    pb_opt += '<div class="table-responsive" style="overflow: auto;height: 370px;">'
    pb_opt += ' <table border=1  width="100%" class="table-hover" class="table table-fixed" class="table-fixed"    id="tabid">'
    pb_opt += '<th>File Type<th>File Name <th> No.of Reoords'
    var result = all_files.split("], [")
   
    for (var j = 0; j<result.length; j++) {
       var resultx = result[j].split(",")     
       resultx[0]=resultx[0].replace(/\[/g, '')
       resultx[0]=resultx[0].replace(/\'/g, '')
       resultx[1]=resultx[1].replace(/\'/g, '')
       resultx[2]=resultx[2].replace(/\'/g, '')
       resultx[2]=resultx[2].replace(/\]\]/g, '')
      //dataz[1]=dataz[1].replace(/\]/g, '');  
      pb_opt += "<tr><td>" +resultx[0] + "</td>"
      pb_opt += "<td>" + resultx[1] + "</td>"
      pb_opt += "<td>" + resultx[2] + "</td>"

    }
    // pb_opt += '<tr><td colspan="2">&nbsp;</td colspan="2"><tr<td>&nbsp;'
    pb_opt += "<tr><td colspan='3' align='center'>  <input class='btn btn-default' type='button'  name='Submit'  value='Submit' id='button' onclick='processpm1()'></td</tr>"
    pb_opt += "</table><p><p>"
    document.getElementById("pb_select").style.display = "block"
    document.getElementById('pb_select').innerHTML = pb_opt
  }

  if (upload_type != 'P') {

    document.getElementById("show_upload").style.display = "block"
    document.getElementById("show_excel").style.display = "block"

    document.getElementById("error_messg_line").style.display = "block"
    document.getElementById('show_upload').innerHTML = input_upload;
    document.getElementById('show_heading').innerHTML = heading;

    document.getElementById("show_upload").style.display = "block"
    document.getElementById("show_heading").style.display = "block"
    document.getElementById("show_excel").style.display = "block"
  }

}

function processpm() {

  debugger
  var url_direct = document.getElementById("sel_link").value
  document.getElementById("process").style.display = "block"
  //document.getElementById("Submit").disabled = true;
  var form_data = new FormData($('#upload-file')[0]);
 $('.mask').show();

  $.ajax({
    type: "POST",
    data: form_data,
    contentType: false,
    cache: false,
    processData: false,
    //contentType: 'application/json;charset=UTF-8',
    url: url_direct,
    //url:hostname

    success: function (datax) {
     
      $('.mask').hide();
      //document.getElementById("process").style.display="block"
      document.getElementById('process').style.display = "none"
      //document.getElementById("show_error_file").style.display="block"
      //document.getElementById('show_error_file').innerHTML=error_table
      //document.getElementById("Submit").disabled = false
      document.getElementById("error_messg_line").style.display = "block"
      document.getElementById("error_messg_line").innerHTML = datax

    }

  })

}

function processpm1() {
  debugger
  var url_direct = document.getElementById("sel_link").value
    document.getElementById("process").style.display = "block"
  //document.getElementById("Submit").disabled = true;
  var form_data = new FormData($('#upload-file')[0]);
 alert("Job Started , You can we the details in Reports Section")
  $('.mask').show();
  $.ajax({
    type: "POST",
    data: form_data,
    contentType: false,
    cache: false,
    processData: false,
    //contentType: 'application/json;charset=UTF-8',
    url: url_direct,
    //url:hostname

    success: function (datax) {
//      alert(datax)
       $('.mask').hide();
      //document.getElementById("process").style.display="block"
      document.getElementById('process').style.display = "none"
      //document.getElementById("show_error_file").style.display="block"
      //document.getElementById('show_error_file').innerHTML=error_table
      //document.getElementById("Submit").disabled = false
      document.getElementById("error_messg_line").style.display = "block"
      document.getElementById("error_messg_line").innerHTML = datax

    }

  })

}
function validate_login() {
  var username = document.getElementById('username').value
  var password = document.getElementById('password').value

  if (!username) {
    alert("Please Enter User ID")
    return false
  }
  if (!password) {
    alert("Please Enter Password")
    return false
  }


}

function show_joblog() {
  debugger
  $('.mask').show();

  var url_direct="/joblog"
  // for(var x=0;x<=1000000;x++){
  //   setTimeout(loop_ajax(url_direct), 10000);
   var data="A"
  $.ajax({
    type: "POST",
    data: data,
   //contentType: 'application/json;charset=UTF-8',
    url: url_direct,
    //url:hostname

    success: function (datax) {
      
      datax = datax.replace(/\[/g, '');
      datax = datax.replace(/]/g, '')
      datax = datax.replace(/"/g, '')
      datax = datax.replace(/\'/g, '')
      var result = datax.split(",")
     
     
      $('.mask').hide();
      
      var ctr_table ="<table border=1>"
          ctr_table += "<tr><th>File<th>No of Records<th>Processed Records<th>UnProcessed<th>Start Time<th>End Time<th>Elapse Time</tr>"
       for (var i = 0; i < result.length-1; ++i) {
           var unprocessed = result[i+1] - result[i+2]
           ctr_table+="<tr>"
           ctr_table+="<td>" + result[i] + "</td>"
           ctr_table+="<td>" + result[i+1] + "</td>"
           ctr_table+="<td>" + result[i+2] + "</td>"
           ctr_table+="<td>" + unprocessed  + "</td>"
           ctr_table+="<td>" + result[i+3]  + "</td>"
           ctr_table+="<td>" + result[i+4]  + "</td>"
           ctr_table+="<td>" + result[i+5]  + "</td></tr>"
           i=i+5
       }

       ctr_table+="</table>"
      
       document.getElementById("pb_select").style.display = "block"
       document.getElementById('pb_select').innerHTML = ctr_table
        document.getElementById('show_upload').innerHTML = " "
        document.getElementById('show_excel').innerHTML = " "
       document.getElementById("error_messg_line").innerHTML = " "
       document.getElementById("show_upload").style.display = "none"
       document.getElementById("show_excel").style.display = "none"
      //document.getElementById("process").style.display="block"
     
      //document.getElementById('show_error_file').innerHTML=error_table
      //document.getElementById("Submit").disabled = false
     // document.getElementById("error_messg_line").style.display = "block"
      //document.getElementById("error_messg_line").innerHTML = datax

    }

  })

}

function show_config() {
  debugger
  $('.mask').show();

  var url_direct="/configure"
  // for(var x=0;x<=1000000;x++){
  //   setTimeout(loop_ajax(url_direct), 10000);
   var data="A"
  $.ajax({
    type: "POST",
    data: data,
   //contentType: 'application/json;charset=UTF-8',
    url: url_direct,
    //url:hostname

    success: function (datax) {
      
      
      datax = datax.replace(/\[/g, '');
      datax = datax.replace(/]/g, '')
      datax = datax.replace(/"/g, '')
      datax = datax.replace(/\'/g, '')
      var result = datax.split(",")
     
     
      $('.mask').hide();
      
      var pb_opt = " <textarea name='Text1' cols='800' rows='4'>This option will allow to add/modify configuration. "
        pb_opt += "The option allows to modify the server name where the application hosted,username and password for MSSQL Database"
        pb_opt += "Also folders where users can copy the input masters.</textarea><p><p><br>"
        pb_opt += ' <div class="tabrow">'
        pb_opt += '<div class="table-responsive" style="overflow: auto;height: 400px;">'
        pb_opt += ' <table border=1  width="100%" class="table-hover" class="table table-fixed" class="table-fixed"    id="tabid">'
        pb_opt += '<th>Type<th>Existing<th> New'
     //var ctr_table =' <table border=1 class="table-hover" class="table table-fixed" class="table-fixed" id="tabid">'
             for (var i = 0; i < result.length-1; i++) {
          
           pb_opt +="<tr>"
           pb_opt +="<td width='10%'>" + result[i] + "</td>"
           pb_opt +="<td width='10%'>" + result[i+1] + "</td>"
           result[i]=result[i].replace(/ /g,'')
           pb_opt +="<td width='10%'><input type=text  value = '' class='intext " +  " 'id='" + result[i] +  "'></input></td>"
           
           i=i+1
       }
       pb_opt+= '<tr><td colspan="3" align="center">  <input class="btn btn-default" type="button" value="Submit " name="Submit"  onclick="process_config()" style="width: 90px;"></td</tr></table> '
       pb_opt+="</table>"
        
        
        document.getElementById("pb_select").style.display = "block"
        document.getElementById('pb_select').innerHTML = pb_opt
        document.getElementById('show_upload').innerHTML = " "
        document.getElementById('show_excel').innerHTML = " "
        document.getElementById("error_messg_line").innerHTML = " "
        document.getElementById("show_upload").style.display = "none"
        document.getElementById("show_excel").style.display = "none"
      //document.getElementById("process").style.display="block"
     
      //document.getElementById('show_error_file').innerHTML=error_table
      //document.getElementById("Submit").disabled = false
     // document.getElementById("error_messg_line").style.display = "block"
      //document.getElementById("error_messg_line").innerHTML = datax

    }

  })

}

function process_config() {
  debugger
  $('.mask').show();
  
  var url_direct="/process_config"
  var server=document.getElementById("server").value
  var user=document.getElementById("User").value
  var password=document.getElementById("Password").value
  var port=document.getElementById("Port").value
 
  var pm=document.getElementById("PM").value
  var ac=document.getElementById("AC").value
  var pb=document.getElementById("PB").value
  var po=document.getElementById("PO").value
  var pr=document.getElementById("PR").value
  if (port==null) {
    port=""
  }


  // for(var x=0;x<=1000000;x++){
  //   setTimeout(loop_ajax(url_direct), 10000);
   
  $.ajax({
    type: "POST",
    data: {server:server,user:user,password:password,pm:pm,ac:ac,pr:pr,pb:pb,po:po},
   //contentType: 'application/json;charset=UTF-8',
    url: url_direct,
    //url:hostname

    success: function (datax) {
      
       $('.mask').hide();
  var datay=datax.split(',')
  
  document.getElementById("server").value=datay[0]
  document.getElementById("User").value=datay[1]
  document.getElementById("Password").value=datay[2]
  document.getElementById("Port").value=datay[3]
  document.getElementById("PM").value=datay[4]
  document.getElementById("AC").value=datay[5]
  document.getElementById("PR").value=datay[6]
  document.getElementById("PB").value=datay[7]
  document.getElementById("PO").value=datay[8]
     

    }

  })

}
  

function validate_admin() {

  var username = document.getElementById('userid').value
  var password = document.getElementById('password').value
  var password1 = document.getElementById('password1').value
  var userlevel = document.getElementById('userlevel').value

  if (!username) {
    alert("Please Enter User ID")
    return false
  }
  if (!password) {
    alert("Please Enter Password")
    return false
  }

  if (!password1) {
    alert("Please Retype Password")
    return false
  }

  if (!userlevel) {
    alert("Please select user level")
    return false
  }

  if (password != password1) {
    alert("Password Not Matching")
    return false
  }
}


function flowchart1() {

  if (i % 2 == 0) {
    document.getElementById("image").style.display = "none"
    document.getElementById("image1").style.display = "block"
    document.getElementById('FlowChart').innerHTML = 'Hide';
  }
  else {
    document.getElementById("image").style.display = "block"
    document.getElementById("image1").style.display = "none"
    document.getElementById('FlowChart').innerHTML = 'Model';
  }
  i = i + 1;

}

function validate_port_input() {

  var infile = document.getElementById("infile").value
  if (!infile) {
    alert("Please Select Input File")
    return false
  }
}


function validate_pb_input() {


  var infile = document.getElementById("infile").value
  if (!infile) {
    alert("Please Select Input File ")
    return false
  }
  if (!(document.getElementById("portfolio").checked)) {
    alert("Please select  contract type")
    return false
  }


}



function validate_pm_input() {

  var infile = document.getElementById("infile").value
  if (!infile) {
    alert("Please Select Input File")
    return false
  }
  var extension = infile.split('.').pop().toLowerCase();
  var allowed = ['xls', 'xlsx', 'csv', 'CSV'];

  if (allowed.indexOf(extension) === -1) {
    // Not valid.
    alert("Application will support excel or csv files only")
    return false
  }

  if (!(document.getElementById("stdtemp").checked) && !(document.getElementById("nonstdtemp").checked)) {
    alert("Please select either Standard Template or Non Standard Template")
    return false
  }


}

function validate_input() {



  var month = document.getElementById("ifrs_mm").value

  if (month == '00') {
    alert("Please Select Month")
    return false
  }


  var year = document.getElementById("ifrs_yy").value
  if (year == 'Year') {
    alert("Please Select Year")
    return false
  }


  var infile = document.getElementById("infile").value
  if (!infile) {
    alert("Please Select Input File")
    return false
  }
  var extension = infile.split('.').pop().toLowerCase();
  var allowed = ['xls', 'xlsx', 'csv', 'CSV'];

  if (allowed.indexOf(extension) === -1) {
    // Not valid.
    alert("Application will support excel or csv files only")
    return false
  }

  if (!(document.getElementById("stdtemp").checked) && !(document.getElementById("nonstdtemp").checked)) {
    alert("Please select either Standard Template or Non Standard Template")
    return false
  }


}

function load_data() {
  //alert("this is working")

  var list1 = document.getElementById("item_list").value
  arrayOfArrays = JSON.parse(list1)
  //alert(arrayOfArrays.length)
  //alert(arrayOfArrays[0])
  for (var i = 0; i < arrayOfArrays.length; i++) {
    var x = arrayOfArrays[i]
    document.getElementById(x[0]).value = x[1]

  }
}

function closeMe() {
  open(location, '_self').close();
}


function get_errors() {
  debugger;
  var error_file= document.getElementById("error_file").value
  document.getElementById("process").style.display = "block"
  //document.getElementById("tabrow").style.display="none"
  //document.getElementById("table-responsive").style.display="none"
  var error_file = document.getElementById("error_file").value

  var url_direct = "/errorfile"
    ;

  $.ajax({

    type: "POST",
    data: {'data':error_file},
   // dataType: 'text',
    //cache: false,
    // contentType: 'application/json;charset=UTF-8',
    url: url_direct,
    //url:hostname

    success: function (datax) {


      document.getElementById("show_upload").style.display = "none"
      document.getElementById("pb_select").style.display = "none"
      document.getElementById("error_messg_line").style.display = "none"
      document.getElementById("process").style.display = "none"
      var result = datax.split("^^^")
      //document.getElementById("tabrow").style.display="block"
      //document.getElementById("table-responsive").style.display="block"
      var pb_opt = ' <div class="tabrow">'
      pb_opt += '<div class="table-responsive" style="overflow: auto;height: 360px;">'
      pb_opt += ' <table  class="table-hover" border=1 class="table table-fixed" class="table-fixed"    id="tabid">'
     
      for (var j = 0; j < result.length; j++) {
        result[j] = result[j].replace(/\[/g, '');
        result[j] = result[j].replace(/\]/g, '');
        result[j] = result[j].replace(/\'/g, '');
        pb_opt += "<tr><td>" + result[j] + "</label></td></tr>"
      }
      pb_opt += "</table>"
      document.getElementById("pb_select").style.display = "block"
      document.getElementById('pb_select').innerHTML = pb_opt
    }

  })

}
